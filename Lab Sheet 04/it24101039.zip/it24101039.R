#set working directory
setwd("C:\\Users\\it24101039\\Desktop\\it24101039")

branch_data<-read.csv("Exercise.txt")

head(branch_data)

#3. Obtain boxplot for sales and interpret the shape of the sales distribution
boxplot(branch_data$Sales_X1,main ="Boxplot of sales",ylab ="sales",col = "green")

#4. Calculate the five number summary and IQR for advertising variable.
summary(branch_data$Advertising_X2)
IQR_advertising<- IQR(branch_data$Advertising_X2)
IQR_advertising

#5. Write an R function to find the outliers in a numeric vector and check for outliersin years variables.
find_outliers<-function(X){
   Q1 <- quantile(X,0.25)
   Q3 <-quantile(X,0.75)
   IQR_value <- IQR (SX)
   
   lower_bound <-Q1 -1.5 * IQR_value
   upper_bound <- Q3 +1.5 * IQR_value
   
#identify outliers
   outliers <-x[x<lower_bound | x > upper_bound]
   return(outliers)
}

outliers_years<- find_outliers(branch_data$Years_x3)
outliers_years
