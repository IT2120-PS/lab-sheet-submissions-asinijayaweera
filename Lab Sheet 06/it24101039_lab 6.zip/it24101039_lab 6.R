setwd("C:\\Users\\Asus\\Desktop\\it24101039 Lab 6")

#Exersice

#1 i Binomeal Distribution
1-pbinom(46,50,0.85,lower.tail = TRUE)

#2
#X= Number of calls recieved in one hour
# poisson distribution
dpois(15,12)
